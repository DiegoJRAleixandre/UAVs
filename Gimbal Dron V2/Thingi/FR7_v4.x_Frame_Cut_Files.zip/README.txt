                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3590777
FR7 v4.x Frame Cut Files by stynkebutt is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

***NOT FOR COMMERCIAL USE***

5/23/2019 Update:  Files have been re-uploaded as Metric files, previous files were in English units.

FR7 v4.x Frame Files
Only the latest and greatest cut files will be posted.  Old files will be removed.

7" Arms
No Props In View, No Cropping Required

v4.1 Rear Plates now include 30x30 stack holes and adjusted lightening cutouts.

Recommended Plate Thicknesses:
- Front Plate w/ and w/o slots:  2.5mm
- Rear Plate w/ and w/o slots:  2.0mm
- Top Plate w/ CG markers:  2.5mm
- Front Arm:  6mm
- Rear Arm:  6mm

Hardware BOM:
Description; Qty; Notes
3mm Standoff, Round (5mm OD), 10mm; 2; Front
3mm Standoff, Round (5mm OD), 20mm; 2; Rear
3mm Standoff, Round (5mm OD), 28mm; 2; Cam Uprights
3mm Standoff, Round (5mm OD), 30mm; 2; HD Camera Holder
Button Head Screw, M3 x 5; 2; Front Standoffs
Button Head Screw, M3 x 8; 14; Standoffs
Button Head Screw, M3 x 12; 8; Arms
SHCS, M3 x 10; 16; Motors w/ Arm Guards
3mm Press Nuts; 8; https://www.mcmaster.com/94100a110 or equivalent

3D Print files:  https://www.thingiverse.com/thing:3601947